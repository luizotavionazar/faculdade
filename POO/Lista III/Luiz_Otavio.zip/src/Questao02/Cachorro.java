package Questao02;

public class Cachorro extends Animal{

    public String late () {
        return "AU AU AU";
    }

}