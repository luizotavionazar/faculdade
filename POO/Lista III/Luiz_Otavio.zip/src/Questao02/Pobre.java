package Questao02;

public class Pobre extends Pessoa{

    public void trabalha() {
        System.out.println("Pobre sofre!!");
    }
    
}