package Questao02;

public class Gato extends Animal{
    
    public String mia() {
        return "MIAU MIAU";
    }

}