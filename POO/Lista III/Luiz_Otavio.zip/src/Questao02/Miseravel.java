package Questao02;

public class Miseravel extends Pessoa{

    public void mendiga() {
        System.out.println("O miseravel é um gênio!! E pede dinheiro...");
    }

}